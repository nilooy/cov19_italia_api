# API Cov19 Italia, Source: Protezione Civile

endpoints: {
regione: "/regione",
province: "/province",
stats: '/stats'
},
